// Generated from /home/jesus/IdeaProjects/PsiCoder2/Psicoder.g4 by ANTLR 4.7
import org.antlr.v4.runtime.atn.*;
import org.antlr.v4.runtime.dfa.DFA;
import org.antlr.v4.runtime.*;
import org.antlr.v4.runtime.misc.*;
import org.antlr.v4.runtime.tree.*;
import java.util.List;
import java.util.Iterator;
import java.util.ArrayList;

@SuppressWarnings({"all", "warnings", "unchecked", "unused", "cast"})
public class PsicoderParser extends Parser {
	static { RuntimeMetaData.checkVersion("4.7", RuntimeMetaData.VERSION); }

	protected static final DFA[] _decisionToDFA;
	protected static final PredictionContextCache _sharedContextCache =
		new PredictionContextCache();
	public static final int
		TK_FUNCIONPRINCIPAL=1, TK_FINPRINCIPAL=2, TK_CHAR=3, TK_BOOL=4, TK_CAD=5, 
		TK_INT=6, TK_DOUBLE=7, TK_ROMPER=8, TK_LEER=9, TK_IMPRIMIR=10, TK_FUNCION=11, 
		TK_HACER=12, TK_RETORNAR=13, TK_FINFUNCION=14, TK_SI=15, TK_ENTONCES=16, 
		TK_FINSI=17, TK_SINO=18, TK_PARA=19, TK_FINPARA=20, TK_MIENTRAS=21, TK_FINMIENTRAS=22, 
		TK_SELECCIONAR=23, TK_ENTRE=24, TK_FINSELECCIONAR=25, TK_CASO=26, TK_DEFECTO=27, 
		TK_ESTRUCTURA=28, TK_FINESTRUCTURA=29, COMMENT=30, LINE_COMMENT=31, ID=32, 
		WS=33, TK_PAR_IZQ=34, TK_PAR_DER=35, TK_PYC=36, TK_PUNTO=37, TK_COMA=38, 
		TK_ASIG=39, TK_DOSP=40, TK_ENTERO=41, TK_REAL=42, TK_CADENA=43, TK_CARACTER=44, 
		VERDADERO=45, FALSO=46, TK_MAS=47, TK_MENOS=48, TK_MULT=49, TK_DIV=50, 
		TK_MOD=51, TK_MENOR=52, TK_MAYOR=53, TK_MENOR_IGUAL=54, TK_MAYOR_IGUAL=55, 
		TK_IGUAL=56, TK_Y=57, TK_O=58, TK_DIF=59, TK_NEG=60;
	public static final int
		RULE_s = 0, RULE_code = 1, RULE_cond = 2, RULE_cv = 3, RULE_cond1 = 4, 
		RULE_sc = 5, RULE_pyc = 6, RULE_dy = 7, RULE_t = 8, RULE_d = 9, RULE_d1 = 10, 
		RULE_a = 11, RULE_a1 = 12, RULE_a2 = 13, RULE_com = 14, RULE_m = 15, RULE_f = 16, 
		RULE_ify = 17, RULE_elsey = 18, RULE_fory = 19, RULE_whiley = 20, RULE_do_whiley = 21, 
		RULE_switchy = 22, RULE_casey = 23, RULE_e = 24, RULE_vt = 25, RULE_opa = 26, 
		RULE_opl = 27;
	public static final String[] ruleNames = {
		"s", "code", "cond", "cv", "cond1", "sc", "pyc", "dy", "t", "d", "d1", 
		"a", "a1", "a2", "com", "m", "f", "ify", "elsey", "fory", "whiley", "do_whiley", 
		"switchy", "casey", "e", "vt", "opa", "opl"
	};

	private static final String[] _LITERAL_NAMES = {
		null, "'funcion_principal'", "'fin_principal'", "'caracter'", "'booleano'", 
		"'cadena'", "'entero'", "'real'", "'romper'", "'leer'", "'imprimir'", 
		"'funcion'", "'hacer'", "'retornar'", "'fin_funcion'", "'si'", "'entonces'", 
		"'fin_si'", "'si_no'", "'para'", "'fin_para'", "'mientras'", "'fin_mientras'", 
		"'seleccionar'", "'entre'", "'fin_seleccionar'", "'caso'", "'defecto'", 
		"'estructura'", "'fin_estructura'", null, null, null, null, "'('", "')'", 
		"';'", "'.'", "','", "'='", "':'", null, null, null, null, "'verdadero'", 
		"'falso'", "'+'", "'-'", "'*'", "'/'", "'%'", "'<'", "'>'", "'<='", "'>='", 
		"'=='", "'&&'", "'||'", "'!='", "'!'"
	};
	private static final String[] _SYMBOLIC_NAMES = {
		null, "TK_FUNCIONPRINCIPAL", "TK_FINPRINCIPAL", "TK_CHAR", "TK_BOOL", 
		"TK_CAD", "TK_INT", "TK_DOUBLE", "TK_ROMPER", "TK_LEER", "TK_IMPRIMIR", 
		"TK_FUNCION", "TK_HACER", "TK_RETORNAR", "TK_FINFUNCION", "TK_SI", "TK_ENTONCES", 
		"TK_FINSI", "TK_SINO", "TK_PARA", "TK_FINPARA", "TK_MIENTRAS", "TK_FINMIENTRAS", 
		"TK_SELECCIONAR", "TK_ENTRE", "TK_FINSELECCIONAR", "TK_CASO", "TK_DEFECTO", 
		"TK_ESTRUCTURA", "TK_FINESTRUCTURA", "COMMENT", "LINE_COMMENT", "ID", 
		"WS", "TK_PAR_IZQ", "TK_PAR_DER", "TK_PYC", "TK_PUNTO", "TK_COMA", "TK_ASIG", 
		"TK_DOSP", "TK_ENTERO", "TK_REAL", "TK_CADENA", "TK_CARACTER", "VERDADERO", 
		"FALSO", "TK_MAS", "TK_MENOS", "TK_MULT", "TK_DIV", "TK_MOD", "TK_MENOR", 
		"TK_MAYOR", "TK_MENOR_IGUAL", "TK_MAYOR_IGUAL", "TK_IGUAL", "TK_Y", "TK_O", 
		"TK_DIF", "TK_NEG"
	};
	public static final Vocabulary VOCABULARY = new VocabularyImpl(_LITERAL_NAMES, _SYMBOLIC_NAMES);

	/**
	 * @deprecated Use {@link #VOCABULARY} instead.
	 */
	@Deprecated
	public static final String[] tokenNames;
	static {
		tokenNames = new String[_SYMBOLIC_NAMES.length];
		for (int i = 0; i < tokenNames.length; i++) {
			tokenNames[i] = VOCABULARY.getLiteralName(i);
			if (tokenNames[i] == null) {
				tokenNames[i] = VOCABULARY.getSymbolicName(i);
			}

			if (tokenNames[i] == null) {
				tokenNames[i] = "<INVALID>";
			}
		}
	}

	@Override
	@Deprecated
	public String[] getTokenNames() {
		return tokenNames;
	}

	@Override

	public Vocabulary getVocabulary() {
		return VOCABULARY;
	}

	@Override
	public String getGrammarFileName() { return "Psicoder.g4"; }

	@Override
	public String[] getRuleNames() { return ruleNames; }

	@Override
	public String getSerializedATN() { return _serializedATN; }

	@Override
	public ATN getATN() { return _ATN; }

	public PsicoderParser(TokenStream input) {
		super(input);
		_interp = new ParserATNSimulator(this,_ATN,_decisionToDFA,_sharedContextCache);
	}
	public static class SContext extends ParserRuleContext {
		public TerminalNode TK_FUNCIONPRINCIPAL() { return getToken(PsicoderParser.TK_FUNCIONPRINCIPAL, 0); }
		public CodeContext code() {
			return getRuleContext(CodeContext.class,0);
		}
		public TerminalNode TK_FINPRINCIPAL() { return getToken(PsicoderParser.TK_FINPRINCIPAL, 0); }
		public List<FContext> f() {
			return getRuleContexts(FContext.class);
		}
		public FContext f(int i) {
			return getRuleContext(FContext.class,i);
		}
		public List<EContext> e() {
			return getRuleContexts(EContext.class);
		}
		public EContext e(int i) {
			return getRuleContext(EContext.class,i);
		}
		public TerminalNode EOF() { return getToken(PsicoderParser.EOF, 0); }
		public SContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_s; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof PsicoderListener ) ((PsicoderListener)listener).enterS(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof PsicoderListener ) ((PsicoderListener)listener).exitS(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof PsicoderVisitor ) return ((PsicoderVisitor<? extends T>)visitor).visitS(this);
			else return visitor.visitChildren(this);
		}
	}

	public final SContext s() throws RecognitionException {
		SContext _localctx = new SContext(_ctx, getState());
		enterRule(_localctx, 0, RULE_s);
		int _la;
		try {
			setState(68);
			_errHandler.sync(this);
			switch (_input.LA(1)) {
			case TK_FUNCIONPRINCIPAL:
			case TK_FUNCION:
			case TK_ESTRUCTURA:
				enterOuterAlt(_localctx, 1);
				{
				setState(60);
				_errHandler.sync(this);
				_la = _input.LA(1);
				while (_la==TK_FUNCION || _la==TK_ESTRUCTURA) {
					{
					setState(58);
					_errHandler.sync(this);
					switch (_input.LA(1)) {
					case TK_FUNCION:
						{
						setState(56);
						f();
						}
						break;
					case TK_ESTRUCTURA:
						{
						setState(57);
						e();
						}
						break;
					default:
						throw new NoViableAltException(this);
					}
					}
					setState(62);
					_errHandler.sync(this);
					_la = _input.LA(1);
				}
				setState(63);
				match(TK_FUNCIONPRINCIPAL);
				setState(64);
				code();
				setState(65);
				match(TK_FINPRINCIPAL);
				}
				break;
			case EOF:
				enterOuterAlt(_localctx, 2);
				{
				setState(67);
				match(EOF);
				}
				break;
			default:
				throw new NoViableAltException(this);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class CodeContext extends ParserRuleContext {
		public List<PycContext> pyc() {
			return getRuleContexts(PycContext.class);
		}
		public PycContext pyc(int i) {
			return getRuleContext(PycContext.class,i);
		}
		public List<ScContext> sc() {
			return getRuleContexts(ScContext.class);
		}
		public ScContext sc(int i) {
			return getRuleContext(ScContext.class,i);
		}
		public CodeContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_code; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof PsicoderListener ) ((PsicoderListener)listener).enterCode(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof PsicoderListener ) ((PsicoderListener)listener).exitCode(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof PsicoderVisitor ) return ((PsicoderVisitor<? extends T>)visitor).visitCode(this);
			else return visitor.visitChildren(this);
		}
	}

	public final CodeContext code() throws RecognitionException {
		CodeContext _localctx = new CodeContext(_ctx, getState());
		enterRule(_localctx, 2, RULE_code);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(74);
			_errHandler.sync(this);
			_la = _input.LA(1);
			while ((((_la) & ~0x3f) == 0 && ((1L << _la) & ((1L << TK_CHAR) | (1L << TK_BOOL) | (1L << TK_CAD) | (1L << TK_INT) | (1L << TK_DOUBLE) | (1L << TK_ROMPER) | (1L << TK_LEER) | (1L << TK_IMPRIMIR) | (1L << TK_HACER) | (1L << TK_SI) | (1L << TK_PARA) | (1L << TK_MIENTRAS) | (1L << TK_SELECCIONAR) | (1L << ID) | (1L << TK_PYC))) != 0)) {
				{
				setState(72);
				_errHandler.sync(this);
				switch (_input.LA(1)) {
				case TK_CHAR:
				case TK_BOOL:
				case TK_CAD:
				case TK_INT:
				case TK_DOUBLE:
				case TK_ROMPER:
				case TK_LEER:
				case TK_IMPRIMIR:
				case ID:
				case TK_PYC:
					{
					setState(70);
					pyc();
					}
					break;
				case TK_HACER:
				case TK_SI:
				case TK_PARA:
				case TK_MIENTRAS:
				case TK_SELECCIONAR:
					{
					setState(71);
					sc();
					}
					break;
				default:
					throw new NoViableAltException(this);
				}
				}
				setState(76);
				_errHandler.sync(this);
				_la = _input.LA(1);
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class CondContext extends ParserRuleContext {
		public DContext d() {
			return getRuleContext(DContext.class,0);
		}
		public OplContext opl() {
			return getRuleContext(OplContext.class,0);
		}
		public CvContext cv() {
			return getRuleContext(CvContext.class,0);
		}
		public Cond1Context cond1() {
			return getRuleContext(Cond1Context.class,0);
		}
		public VtContext vt() {
			return getRuleContext(VtContext.class,0);
		}
		public TerminalNode TK_PAR_IZQ() { return getToken(PsicoderParser.TK_PAR_IZQ, 0); }
		public CondContext cond() {
			return getRuleContext(CondContext.class,0);
		}
		public TerminalNode TK_PAR_DER() { return getToken(PsicoderParser.TK_PAR_DER, 0); }
		public CondContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_cond; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof PsicoderListener ) ((PsicoderListener)listener).enterCond(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof PsicoderListener ) ((PsicoderListener)listener).exitCond(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof PsicoderVisitor ) return ((PsicoderVisitor<? extends T>)visitor).visitCond(this);
			else return visitor.visitChildren(this);
		}
	}

	public final CondContext cond() throws RecognitionException {
		CondContext _localctx = new CondContext(_ctx, getState());
		enterRule(_localctx, 4, RULE_cond);
		try {
			setState(92);
			_errHandler.sync(this);
			switch (_input.LA(1)) {
			case ID:
				enterOuterAlt(_localctx, 1);
				{
				setState(77);
				d();
				setState(78);
				opl();
				setState(79);
				cv();
				setState(80);
				cond1();
				}
				break;
			case TK_ENTERO:
			case TK_REAL:
			case TK_CADENA:
			case TK_CARACTER:
			case VERDADERO:
			case FALSO:
				enterOuterAlt(_localctx, 2);
				{
				setState(82);
				vt();
				setState(83);
				opl();
				setState(84);
				cv();
				setState(85);
				cond1();
				}
				break;
			case TK_PAR_IZQ:
				enterOuterAlt(_localctx, 3);
				{
				setState(87);
				match(TK_PAR_IZQ);
				setState(88);
				cond();
				setState(89);
				match(TK_PAR_DER);
				setState(90);
				cond1();
				}
				break;
			default:
				throw new NoViableAltException(this);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class CvContext extends ParserRuleContext {
		public VtContext vt() {
			return getRuleContext(VtContext.class,0);
		}
		public DContext d() {
			return getRuleContext(DContext.class,0);
		}
		public CvContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_cv; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof PsicoderListener ) ((PsicoderListener)listener).enterCv(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof PsicoderListener ) ((PsicoderListener)listener).exitCv(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof PsicoderVisitor ) return ((PsicoderVisitor<? extends T>)visitor).visitCv(this);
			else return visitor.visitChildren(this);
		}
	}

	public final CvContext cv() throws RecognitionException {
		CvContext _localctx = new CvContext(_ctx, getState());
		enterRule(_localctx, 6, RULE_cv);
		try {
			setState(96);
			_errHandler.sync(this);
			switch (_input.LA(1)) {
			case TK_ENTERO:
			case TK_REAL:
			case TK_CADENA:
			case TK_CARACTER:
			case VERDADERO:
			case FALSO:
				enterOuterAlt(_localctx, 1);
				{
				setState(94);
				vt();
				}
				break;
			case ID:
				enterOuterAlt(_localctx, 2);
				{
				setState(95);
				d();
				}
				break;
			default:
				throw new NoViableAltException(this);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class Cond1Context extends ParserRuleContext {
		public OplContext opl() {
			return getRuleContext(OplContext.class,0);
		}
		public CondContext cond() {
			return getRuleContext(CondContext.class,0);
		}
		public Cond1Context cond1() {
			return getRuleContext(Cond1Context.class,0);
		}
		public Cond1Context(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_cond1; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof PsicoderListener ) ((PsicoderListener)listener).enterCond1(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof PsicoderListener ) ((PsicoderListener)listener).exitCond1(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof PsicoderVisitor ) return ((PsicoderVisitor<? extends T>)visitor).visitCond1(this);
			else return visitor.visitChildren(this);
		}
	}

	public final Cond1Context cond1() throws RecognitionException {
		Cond1Context _localctx = new Cond1Context(_ctx, getState());
		enterRule(_localctx, 8, RULE_cond1);
		try {
			setState(103);
			_errHandler.sync(this);
			switch ( getInterpreter().adaptivePredict(_input,7,_ctx) ) {
			case 1:
				enterOuterAlt(_localctx, 1);
				{
				setState(98);
				opl();
				setState(99);
				cond();
				setState(100);
				cond1();
				}
				break;
			case 2:
				enterOuterAlt(_localctx, 2);
				{
				}
				break;
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class ScContext extends ParserRuleContext {
		public IfyContext ify() {
			return getRuleContext(IfyContext.class,0);
		}
		public ForyContext fory() {
			return getRuleContext(ForyContext.class,0);
		}
		public WhileyContext whiley() {
			return getRuleContext(WhileyContext.class,0);
		}
		public Do_whileyContext do_whiley() {
			return getRuleContext(Do_whileyContext.class,0);
		}
		public SwitchyContext switchy() {
			return getRuleContext(SwitchyContext.class,0);
		}
		public ScContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_sc; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof PsicoderListener ) ((PsicoderListener)listener).enterSc(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof PsicoderListener ) ((PsicoderListener)listener).exitSc(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof PsicoderVisitor ) return ((PsicoderVisitor<? extends T>)visitor).visitSc(this);
			else return visitor.visitChildren(this);
		}
	}

	public final ScContext sc() throws RecognitionException {
		ScContext _localctx = new ScContext(_ctx, getState());
		enterRule(_localctx, 10, RULE_sc);
		try {
			setState(110);
			_errHandler.sync(this);
			switch (_input.LA(1)) {
			case TK_SI:
				enterOuterAlt(_localctx, 1);
				{
				setState(105);
				ify();
				}
				break;
			case TK_PARA:
				enterOuterAlt(_localctx, 2);
				{
				setState(106);
				fory();
				}
				break;
			case TK_MIENTRAS:
				enterOuterAlt(_localctx, 3);
				{
				setState(107);
				whiley();
				}
				break;
			case TK_HACER:
				enterOuterAlt(_localctx, 4);
				{
				setState(108);
				do_whiley();
				}
				break;
			case TK_SELECCIONAR:
				enterOuterAlt(_localctx, 5);
				{
				setState(109);
				switchy();
				}
				break;
			default:
				throw new NoViableAltException(this);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class PycContext extends ParserRuleContext {
		public DyContext dy() {
			return getRuleContext(DyContext.class,0);
		}
		public TerminalNode TK_PYC() { return getToken(PsicoderParser.TK_PYC, 0); }
		public ComContext com() {
			return getRuleContext(ComContext.class,0);
		}
		public PycContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_pyc; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof PsicoderListener ) ((PsicoderListener)listener).enterPyc(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof PsicoderListener ) ((PsicoderListener)listener).exitPyc(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof PsicoderVisitor ) return ((PsicoderVisitor<? extends T>)visitor).visitPyc(this);
			else return visitor.visitChildren(this);
		}
	}

	public final PycContext pyc() throws RecognitionException {
		PycContext _localctx = new PycContext(_ctx, getState());
		enterRule(_localctx, 12, RULE_pyc);
		try {
			setState(118);
			_errHandler.sync(this);
			switch ( getInterpreter().adaptivePredict(_input,9,_ctx) ) {
			case 1:
				enterOuterAlt(_localctx, 1);
				{
				setState(112);
				dy();
				setState(113);
				match(TK_PYC);
				}
				break;
			case 2:
				enterOuterAlt(_localctx, 2);
				{
				setState(115);
				com();
				setState(116);
				match(TK_PYC);
				}
				break;
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class DyContext extends ParserRuleContext {
		public TContext t() {
			return getRuleContext(TContext.class,0);
		}
		public DContext d() {
			return getRuleContext(DContext.class,0);
		}
		public AContext a() {
			return getRuleContext(AContext.class,0);
		}
		public DyContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_dy; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof PsicoderListener ) ((PsicoderListener)listener).enterDy(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof PsicoderListener ) ((PsicoderListener)listener).exitDy(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof PsicoderVisitor ) return ((PsicoderVisitor<? extends T>)visitor).visitDy(this);
			else return visitor.visitChildren(this);
		}
	}

	public final DyContext dy() throws RecognitionException {
		DyContext _localctx = new DyContext(_ctx, getState());
		enterRule(_localctx, 14, RULE_dy);
		try {
			setState(128);
			_errHandler.sync(this);
			switch (_input.LA(1)) {
			case TK_CHAR:
			case TK_BOOL:
			case TK_CAD:
			case TK_INT:
			case TK_DOUBLE:
				enterOuterAlt(_localctx, 1);
				{
				setState(120);
				t();
				setState(121);
				d();
				setState(122);
				a();
				}
				break;
			case ID:
				enterOuterAlt(_localctx, 2);
				{
				setState(124);
				d();
				setState(125);
				a();
				}
				break;
			case TK_PYC:
				enterOuterAlt(_localctx, 3);
				{
				}
				break;
			default:
				throw new NoViableAltException(this);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class TContext extends ParserRuleContext {
		public TerminalNode TK_CHAR() { return getToken(PsicoderParser.TK_CHAR, 0); }
		public TerminalNode TK_BOOL() { return getToken(PsicoderParser.TK_BOOL, 0); }
		public TerminalNode TK_CAD() { return getToken(PsicoderParser.TK_CAD, 0); }
		public TerminalNode TK_INT() { return getToken(PsicoderParser.TK_INT, 0); }
		public TerminalNode TK_DOUBLE() { return getToken(PsicoderParser.TK_DOUBLE, 0); }
		public TContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_t; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof PsicoderListener ) ((PsicoderListener)listener).enterT(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof PsicoderListener ) ((PsicoderListener)listener).exitT(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof PsicoderVisitor ) return ((PsicoderVisitor<? extends T>)visitor).visitT(this);
			else return visitor.visitChildren(this);
		}
	}

	public final TContext t() throws RecognitionException {
		TContext _localctx = new TContext(_ctx, getState());
		enterRule(_localctx, 16, RULE_t);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(130);
			_la = _input.LA(1);
			if ( !((((_la) & ~0x3f) == 0 && ((1L << _la) & ((1L << TK_CHAR) | (1L << TK_BOOL) | (1L << TK_CAD) | (1L << TK_INT) | (1L << TK_DOUBLE))) != 0)) ) {
			_errHandler.recoverInline(this);
			}
			else {
				if ( _input.LA(1)==Token.EOF ) matchedEOF = true;
				_errHandler.reportMatch(this);
				consume();
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class DContext extends ParserRuleContext {
		public TerminalNode ID() { return getToken(PsicoderParser.ID, 0); }
		public D1Context d1() {
			return getRuleContext(D1Context.class,0);
		}
		public DContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_d; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof PsicoderListener ) ((PsicoderListener)listener).enterD(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof PsicoderListener ) ((PsicoderListener)listener).exitD(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof PsicoderVisitor ) return ((PsicoderVisitor<? extends T>)visitor).visitD(this);
			else return visitor.visitChildren(this);
		}
	}

	public final DContext d() throws RecognitionException {
		DContext _localctx = new DContext(_ctx, getState());
		enterRule(_localctx, 18, RULE_d);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(132);
			match(ID);
			setState(133);
			d1();
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class D1Context extends ParserRuleContext {
		public TerminalNode TK_PUNTO() { return getToken(PsicoderParser.TK_PUNTO, 0); }
		public TerminalNode ID() { return getToken(PsicoderParser.ID, 0); }
		public D1Context d1() {
			return getRuleContext(D1Context.class,0);
		}
		public TerminalNode TK_COMA() { return getToken(PsicoderParser.TK_COMA, 0); }
		public TerminalNode TK_PYC() { return getToken(PsicoderParser.TK_PYC, 0); }
		public D1Context(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_d1; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof PsicoderListener ) ((PsicoderListener)listener).enterD1(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof PsicoderListener ) ((PsicoderListener)listener).exitD1(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof PsicoderVisitor ) return ((PsicoderVisitor<? extends T>)visitor).visitD1(this);
			else return visitor.visitChildren(this);
		}
	}

	public final D1Context d1() throws RecognitionException {
		D1Context _localctx = new D1Context(_ctx, getState());
		enterRule(_localctx, 20, RULE_d1);
		try {
			setState(143);
			_errHandler.sync(this);
			switch ( getInterpreter().adaptivePredict(_input,11,_ctx) ) {
			case 1:
				enterOuterAlt(_localctx, 1);
				{
				setState(135);
				match(TK_PUNTO);
				setState(136);
				match(ID);
				}
				break;
			case 2:
				enterOuterAlt(_localctx, 2);
				{
				setState(137);
				match(ID);
				setState(138);
				d1();
				}
				break;
			case 3:
				enterOuterAlt(_localctx, 3);
				{
				setState(139);
				match(TK_COMA);
				setState(140);
				d1();
				}
				break;
			case 4:
				enterOuterAlt(_localctx, 4);
				{
				setState(141);
				match(TK_PYC);
				}
				break;
			case 5:
				enterOuterAlt(_localctx, 5);
				{
				}
				break;
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class AContext extends ParserRuleContext {
		public TerminalNode TK_ASIG() { return getToken(PsicoderParser.TK_ASIG, 0); }
		public AContext a() {
			return getRuleContext(AContext.class,0);
		}
		public A2Context a2() {
			return getRuleContext(A2Context.class,0);
		}
		public VtContext vt() {
			return getRuleContext(VtContext.class,0);
		}
		public A1Context a1() {
			return getRuleContext(A1Context.class,0);
		}
		public TerminalNode TK_PAR_IZQ() { return getToken(PsicoderParser.TK_PAR_IZQ, 0); }
		public TerminalNode TK_PAR_DER() { return getToken(PsicoderParser.TK_PAR_DER, 0); }
		public AContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_a; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof PsicoderListener ) ((PsicoderListener)listener).enterA(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof PsicoderListener ) ((PsicoderListener)listener).exitA(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof PsicoderVisitor ) return ((PsicoderVisitor<? extends T>)visitor).visitA(this);
			else return visitor.visitChildren(this);
		}
	}

	public final AContext a() throws RecognitionException {
		AContext _localctx = new AContext(_ctx, getState());
		enterRule(_localctx, 22, RULE_a);
		try {
			setState(159);
			_errHandler.sync(this);
			switch (_input.LA(1)) {
			case TK_ASIG:
				enterOuterAlt(_localctx, 1);
				{
				setState(145);
				match(TK_ASIG);
				setState(146);
				a();
				setState(147);
				a2();
				}
				break;
			case TK_ENTERO:
			case TK_REAL:
			case TK_CADENA:
			case TK_CARACTER:
			case VERDADERO:
			case FALSO:
				enterOuterAlt(_localctx, 2);
				{
				setState(149);
				vt();
				setState(150);
				a1();
				setState(151);
				a2();
				}
				break;
			case TK_PAR_IZQ:
				enterOuterAlt(_localctx, 3);
				{
				setState(153);
				match(TK_PAR_IZQ);
				setState(154);
				a();
				setState(155);
				match(TK_PAR_DER);
				setState(156);
				a2();
				}
				break;
			case ID:
			case TK_PAR_DER:
			case TK_PYC:
			case TK_MAS:
			case TK_MENOS:
			case TK_MULT:
			case TK_DIV:
			case TK_MOD:
				enterOuterAlt(_localctx, 4);
				{
				}
				break;
			default:
				throw new NoViableAltException(this);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class A1Context extends ParserRuleContext {
		public TerminalNode TK_COMA() { return getToken(PsicoderParser.TK_COMA, 0); }
		public A1Context(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_a1; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof PsicoderListener ) ((PsicoderListener)listener).enterA1(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof PsicoderListener ) ((PsicoderListener)listener).exitA1(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof PsicoderVisitor ) return ((PsicoderVisitor<? extends T>)visitor).visitA1(this);
			else return visitor.visitChildren(this);
		}
	}

	public final A1Context a1() throws RecognitionException {
		A1Context _localctx = new A1Context(_ctx, getState());
		enterRule(_localctx, 24, RULE_a1);
		try {
			setState(163);
			_errHandler.sync(this);
			switch (_input.LA(1)) {
			case TK_COMA:
				enterOuterAlt(_localctx, 1);
				{
				setState(161);
				match(TK_COMA);
				}
				break;
			case ID:
			case TK_PAR_DER:
			case TK_PYC:
			case TK_MAS:
			case TK_MENOS:
			case TK_MULT:
			case TK_DIV:
			case TK_MOD:
				enterOuterAlt(_localctx, 2);
				{
				}
				break;
			default:
				throw new NoViableAltException(this);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class A2Context extends ParserRuleContext {
		public OpaContext opa() {
			return getRuleContext(OpaContext.class,0);
		}
		public AContext a() {
			return getRuleContext(AContext.class,0);
		}
		public A2Context a2() {
			return getRuleContext(A2Context.class,0);
		}
		public DContext d() {
			return getRuleContext(DContext.class,0);
		}
		public TerminalNode TK_PYC() { return getToken(PsicoderParser.TK_PYC, 0); }
		public A2Context(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_a2; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof PsicoderListener ) ((PsicoderListener)listener).enterA2(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof PsicoderListener ) ((PsicoderListener)listener).exitA2(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof PsicoderVisitor ) return ((PsicoderVisitor<? extends T>)visitor).visitA2(this);
			else return visitor.visitChildren(this);
		}
	}

	public final A2Context a2() throws RecognitionException {
		A2Context _localctx = new A2Context(_ctx, getState());
		enterRule(_localctx, 26, RULE_a2);
		try {
			setState(174);
			_errHandler.sync(this);
			switch ( getInterpreter().adaptivePredict(_input,14,_ctx) ) {
			case 1:
				enterOuterAlt(_localctx, 1);
				{
				setState(165);
				opa();
				setState(166);
				a();
				setState(167);
				a2();
				}
				break;
			case 2:
				enterOuterAlt(_localctx, 2);
				{
				setState(169);
				d();
				setState(170);
				a();
				}
				break;
			case 3:
				enterOuterAlt(_localctx, 3);
				{
				setState(172);
				match(TK_PYC);
				}
				break;
			case 4:
				enterOuterAlt(_localctx, 4);
				{
				}
				break;
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class ComContext extends ParserRuleContext {
		public TerminalNode TK_ROMPER() { return getToken(PsicoderParser.TK_ROMPER, 0); }
		public TerminalNode TK_LEER() { return getToken(PsicoderParser.TK_LEER, 0); }
		public TerminalNode TK_PAR_IZQ() { return getToken(PsicoderParser.TK_PAR_IZQ, 0); }
		public TerminalNode ID() { return getToken(PsicoderParser.ID, 0); }
		public TerminalNode TK_PAR_DER() { return getToken(PsicoderParser.TK_PAR_DER, 0); }
		public TerminalNode TK_IMPRIMIR() { return getToken(PsicoderParser.TK_IMPRIMIR, 0); }
		public MContext m() {
			return getRuleContext(MContext.class,0);
		}
		public DContext d() {
			return getRuleContext(DContext.class,0);
		}
		public ComContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_com; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof PsicoderListener ) ((PsicoderListener)listener).enterCom(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof PsicoderListener ) ((PsicoderListener)listener).exitCom(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof PsicoderVisitor ) return ((PsicoderVisitor<? extends T>)visitor).visitCom(this);
			else return visitor.visitChildren(this);
		}
	}

	public final ComContext com() throws RecognitionException {
		ComContext _localctx = new ComContext(_ctx, getState());
		enterRule(_localctx, 28, RULE_com);
		try {
			setState(191);
			_errHandler.sync(this);
			switch (_input.LA(1)) {
			case TK_ROMPER:
				enterOuterAlt(_localctx, 1);
				{
				setState(176);
				match(TK_ROMPER);
				}
				break;
			case TK_LEER:
				enterOuterAlt(_localctx, 2);
				{
				setState(177);
				match(TK_LEER);
				setState(178);
				match(TK_PAR_IZQ);
				setState(179);
				match(ID);
				setState(180);
				match(TK_PAR_DER);
				}
				break;
			case TK_IMPRIMIR:
				enterOuterAlt(_localctx, 3);
				{
				setState(181);
				match(TK_IMPRIMIR);
				setState(182);
				match(TK_PAR_IZQ);
				setState(183);
				m();
				setState(184);
				match(TK_PAR_DER);
				}
				break;
			case ID:
				enterOuterAlt(_localctx, 4);
				{
				setState(186);
				match(ID);
				setState(187);
				match(TK_PAR_IZQ);
				setState(188);
				d();
				setState(189);
				match(TK_PAR_DER);
				}
				break;
			default:
				throw new NoViableAltException(this);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class MContext extends ParserRuleContext {
		public DContext d() {
			return getRuleContext(DContext.class,0);
		}
		public AContext a() {
			return getRuleContext(AContext.class,0);
		}
		public A2Context a2() {
			return getRuleContext(A2Context.class,0);
		}
		public MContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_m; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof PsicoderListener ) ((PsicoderListener)listener).enterM(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof PsicoderListener ) ((PsicoderListener)listener).exitM(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof PsicoderVisitor ) return ((PsicoderVisitor<? extends T>)visitor).visitM(this);
			else return visitor.visitChildren(this);
		}
	}

	public final MContext m() throws RecognitionException {
		MContext _localctx = new MContext(_ctx, getState());
		enterRule(_localctx, 30, RULE_m);
		try {
			setState(196);
			_errHandler.sync(this);
			switch ( getInterpreter().adaptivePredict(_input,16,_ctx) ) {
			case 1:
				enterOuterAlt(_localctx, 1);
				{
				setState(193);
				d();
				}
				break;
			case 2:
				enterOuterAlt(_localctx, 2);
				{
				setState(194);
				a();
				}
				break;
			case 3:
				enterOuterAlt(_localctx, 3);
				{
				setState(195);
				a2();
				}
				break;
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class FContext extends ParserRuleContext {
		public TerminalNode TK_FUNCION() { return getToken(PsicoderParser.TK_FUNCION, 0); }
		public TContext t() {
			return getRuleContext(TContext.class,0);
		}
		public TerminalNode ID() { return getToken(PsicoderParser.ID, 0); }
		public TerminalNode TK_PAR_IZQ() { return getToken(PsicoderParser.TK_PAR_IZQ, 0); }
		public List<DContext> d() {
			return getRuleContexts(DContext.class);
		}
		public DContext d(int i) {
			return getRuleContext(DContext.class,i);
		}
		public TerminalNode TK_PAR_DER() { return getToken(PsicoderParser.TK_PAR_DER, 0); }
		public TerminalNode TK_HACER() { return getToken(PsicoderParser.TK_HACER, 0); }
		public PycContext pyc() {
			return getRuleContext(PycContext.class,0);
		}
		public TerminalNode TK_RETORNAR() { return getToken(PsicoderParser.TK_RETORNAR, 0); }
		public TerminalNode TK_FINFUNCION() { return getToken(PsicoderParser.TK_FINFUNCION, 0); }
		public FContext f() {
			return getRuleContext(FContext.class,0);
		}
		public EContext e() {
			return getRuleContext(EContext.class,0);
		}
		public FContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_f; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof PsicoderListener ) ((PsicoderListener)listener).enterF(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof PsicoderListener ) ((PsicoderListener)listener).exitF(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof PsicoderVisitor ) return ((PsicoderVisitor<? extends T>)visitor).visitF(this);
			else return visitor.visitChildren(this);
		}
	}

	public final FContext f() throws RecognitionException {
		FContext _localctx = new FContext(_ctx, getState());
		enterRule(_localctx, 32, RULE_f);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(198);
			match(TK_FUNCION);
			setState(199);
			t();
			setState(200);
			match(ID);
			setState(201);
			match(TK_PAR_IZQ);
			setState(202);
			d();
			setState(203);
			match(TK_PAR_DER);
			setState(204);
			match(TK_HACER);
			setState(205);
			pyc();
			setState(206);
			match(TK_RETORNAR);
			setState(207);
			d();
			setState(208);
			match(TK_FINFUNCION);
			setState(209);
			f();
			setState(210);
			e();
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class IfyContext extends ParserRuleContext {
		public TerminalNode TK_SI() { return getToken(PsicoderParser.TK_SI, 0); }
		public TerminalNode TK_PAR_IZQ() { return getToken(PsicoderParser.TK_PAR_IZQ, 0); }
		public CondContext cond() {
			return getRuleContext(CondContext.class,0);
		}
		public TerminalNode TK_PAR_DER() { return getToken(PsicoderParser.TK_PAR_DER, 0); }
		public TerminalNode TK_ENTONCES() { return getToken(PsicoderParser.TK_ENTONCES, 0); }
		public PycContext pyc() {
			return getRuleContext(PycContext.class,0);
		}
		public ElseyContext elsey() {
			return getRuleContext(ElseyContext.class,0);
		}
		public TerminalNode TK_FINSI() { return getToken(PsicoderParser.TK_FINSI, 0); }
		public IfyContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_ify; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof PsicoderListener ) ((PsicoderListener)listener).enterIfy(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof PsicoderListener ) ((PsicoderListener)listener).exitIfy(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof PsicoderVisitor ) return ((PsicoderVisitor<? extends T>)visitor).visitIfy(this);
			else return visitor.visitChildren(this);
		}
	}

	public final IfyContext ify() throws RecognitionException {
		IfyContext _localctx = new IfyContext(_ctx, getState());
		enterRule(_localctx, 34, RULE_ify);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(212);
			match(TK_SI);
			setState(213);
			match(TK_PAR_IZQ);
			setState(214);
			cond();
			setState(215);
			match(TK_PAR_DER);
			setState(216);
			match(TK_ENTONCES);
			setState(217);
			pyc();
			setState(218);
			elsey();
			setState(219);
			match(TK_FINSI);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class ElseyContext extends ParserRuleContext {
		public TerminalNode TK_SINO() { return getToken(PsicoderParser.TK_SINO, 0); }
		public PycContext pyc() {
			return getRuleContext(PycContext.class,0);
		}
		public ElseyContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_elsey; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof PsicoderListener ) ((PsicoderListener)listener).enterElsey(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof PsicoderListener ) ((PsicoderListener)listener).exitElsey(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof PsicoderVisitor ) return ((PsicoderVisitor<? extends T>)visitor).visitElsey(this);
			else return visitor.visitChildren(this);
		}
	}

	public final ElseyContext elsey() throws RecognitionException {
		ElseyContext _localctx = new ElseyContext(_ctx, getState());
		enterRule(_localctx, 36, RULE_elsey);
		try {
			setState(224);
			_errHandler.sync(this);
			switch (_input.LA(1)) {
			case TK_SINO:
				enterOuterAlt(_localctx, 1);
				{
				setState(221);
				match(TK_SINO);
				setState(222);
				pyc();
				}
				break;
			case TK_FINSI:
				enterOuterAlt(_localctx, 2);
				{
				}
				break;
			default:
				throw new NoViableAltException(this);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class ForyContext extends ParserRuleContext {
		public TerminalNode TK_PARA() { return getToken(PsicoderParser.TK_PARA, 0); }
		public TerminalNode TK_PAR_IZQ() { return getToken(PsicoderParser.TK_PAR_IZQ, 0); }
		public List<DContext> d() {
			return getRuleContexts(DContext.class);
		}
		public DContext d(int i) {
			return getRuleContext(DContext.class,i);
		}
		public List<TerminalNode> TK_PYC() { return getTokens(PsicoderParser.TK_PYC); }
		public TerminalNode TK_PYC(int i) {
			return getToken(PsicoderParser.TK_PYC, i);
		}
		public CondContext cond() {
			return getRuleContext(CondContext.class,0);
		}
		public TerminalNode TK_PAR_DER() { return getToken(PsicoderParser.TK_PAR_DER, 0); }
		public TerminalNode TK_HACER() { return getToken(PsicoderParser.TK_HACER, 0); }
		public PycContext pyc() {
			return getRuleContext(PycContext.class,0);
		}
		public TerminalNode TK_FINPARA() { return getToken(PsicoderParser.TK_FINPARA, 0); }
		public ForyContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_fory; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof PsicoderListener ) ((PsicoderListener)listener).enterFory(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof PsicoderListener ) ((PsicoderListener)listener).exitFory(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof PsicoderVisitor ) return ((PsicoderVisitor<? extends T>)visitor).visitFory(this);
			else return visitor.visitChildren(this);
		}
	}

	public final ForyContext fory() throws RecognitionException {
		ForyContext _localctx = new ForyContext(_ctx, getState());
		enterRule(_localctx, 38, RULE_fory);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(226);
			match(TK_PARA);
			setState(227);
			match(TK_PAR_IZQ);
			setState(228);
			d();
			setState(229);
			match(TK_PYC);
			setState(230);
			cond();
			setState(231);
			match(TK_PYC);
			setState(232);
			d();
			setState(233);
			match(TK_PAR_DER);
			setState(234);
			match(TK_HACER);
			setState(235);
			pyc();
			setState(236);
			match(TK_FINPARA);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class WhileyContext extends ParserRuleContext {
		public TerminalNode TK_MIENTRAS() { return getToken(PsicoderParser.TK_MIENTRAS, 0); }
		public TerminalNode TK_PAR_IZQ() { return getToken(PsicoderParser.TK_PAR_IZQ, 0); }
		public CondContext cond() {
			return getRuleContext(CondContext.class,0);
		}
		public TerminalNode TK_PAR_DER() { return getToken(PsicoderParser.TK_PAR_DER, 0); }
		public TerminalNode TK_HACER() { return getToken(PsicoderParser.TK_HACER, 0); }
		public PycContext pyc() {
			return getRuleContext(PycContext.class,0);
		}
		public TerminalNode TK_FINMIENTRAS() { return getToken(PsicoderParser.TK_FINMIENTRAS, 0); }
		public WhileyContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_whiley; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof PsicoderListener ) ((PsicoderListener)listener).enterWhiley(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof PsicoderListener ) ((PsicoderListener)listener).exitWhiley(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof PsicoderVisitor ) return ((PsicoderVisitor<? extends T>)visitor).visitWhiley(this);
			else return visitor.visitChildren(this);
		}
	}

	public final WhileyContext whiley() throws RecognitionException {
		WhileyContext _localctx = new WhileyContext(_ctx, getState());
		enterRule(_localctx, 40, RULE_whiley);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(238);
			match(TK_MIENTRAS);
			setState(239);
			match(TK_PAR_IZQ);
			setState(240);
			cond();
			setState(241);
			match(TK_PAR_DER);
			setState(242);
			match(TK_HACER);
			setState(243);
			pyc();
			setState(244);
			match(TK_FINMIENTRAS);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class Do_whileyContext extends ParserRuleContext {
		public TerminalNode TK_HACER() { return getToken(PsicoderParser.TK_HACER, 0); }
		public PycContext pyc() {
			return getRuleContext(PycContext.class,0);
		}
		public TerminalNode TK_MIENTRAS() { return getToken(PsicoderParser.TK_MIENTRAS, 0); }
		public TerminalNode TK_PAR_IZQ() { return getToken(PsicoderParser.TK_PAR_IZQ, 0); }
		public CondContext cond() {
			return getRuleContext(CondContext.class,0);
		}
		public TerminalNode TK_PAR_DER() { return getToken(PsicoderParser.TK_PAR_DER, 0); }
		public TerminalNode TK_PYC() { return getToken(PsicoderParser.TK_PYC, 0); }
		public Do_whileyContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_do_whiley; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof PsicoderListener ) ((PsicoderListener)listener).enterDo_whiley(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof PsicoderListener ) ((PsicoderListener)listener).exitDo_whiley(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof PsicoderVisitor ) return ((PsicoderVisitor<? extends T>)visitor).visitDo_whiley(this);
			else return visitor.visitChildren(this);
		}
	}

	public final Do_whileyContext do_whiley() throws RecognitionException {
		Do_whileyContext _localctx = new Do_whileyContext(_ctx, getState());
		enterRule(_localctx, 42, RULE_do_whiley);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(246);
			match(TK_HACER);
			setState(247);
			pyc();
			setState(248);
			match(TK_MIENTRAS);
			setState(249);
			match(TK_PAR_IZQ);
			setState(250);
			cond();
			setState(251);
			match(TK_PAR_DER);
			setState(252);
			match(TK_PYC);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class SwitchyContext extends ParserRuleContext {
		public TerminalNode TK_SELECCIONAR() { return getToken(PsicoderParser.TK_SELECCIONAR, 0); }
		public TerminalNode TK_PAR_IZQ() { return getToken(PsicoderParser.TK_PAR_IZQ, 0); }
		public TerminalNode ID() { return getToken(PsicoderParser.ID, 0); }
		public TerminalNode TK_PAR_DER() { return getToken(PsicoderParser.TK_PAR_DER, 0); }
		public TerminalNode TK_ENTRE() { return getToken(PsicoderParser.TK_ENTRE, 0); }
		public CaseyContext casey() {
			return getRuleContext(CaseyContext.class,0);
		}
		public TerminalNode TK_FINSELECCIONAR() { return getToken(PsicoderParser.TK_FINSELECCIONAR, 0); }
		public SwitchyContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_switchy; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof PsicoderListener ) ((PsicoderListener)listener).enterSwitchy(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof PsicoderListener ) ((PsicoderListener)listener).exitSwitchy(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof PsicoderVisitor ) return ((PsicoderVisitor<? extends T>)visitor).visitSwitchy(this);
			else return visitor.visitChildren(this);
		}
	}

	public final SwitchyContext switchy() throws RecognitionException {
		SwitchyContext _localctx = new SwitchyContext(_ctx, getState());
		enterRule(_localctx, 44, RULE_switchy);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(254);
			match(TK_SELECCIONAR);
			setState(255);
			match(TK_PAR_IZQ);
			setState(256);
			match(ID);
			setState(257);
			match(TK_PAR_DER);
			setState(258);
			match(TK_ENTRE);
			setState(259);
			casey();
			setState(260);
			match(TK_FINSELECCIONAR);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class CaseyContext extends ParserRuleContext {
		public TerminalNode TK_CASO() { return getToken(PsicoderParser.TK_CASO, 0); }
		public VtContext vt() {
			return getRuleContext(VtContext.class,0);
		}
		public TerminalNode TK_DOSP() { return getToken(PsicoderParser.TK_DOSP, 0); }
		public PycContext pyc() {
			return getRuleContext(PycContext.class,0);
		}
		public CaseyContext casey() {
			return getRuleContext(CaseyContext.class,0);
		}
		public TerminalNode TK_DEFECTO() { return getToken(PsicoderParser.TK_DEFECTO, 0); }
		public CaseyContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_casey; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof PsicoderListener ) ((PsicoderListener)listener).enterCasey(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof PsicoderListener ) ((PsicoderListener)listener).exitCasey(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof PsicoderVisitor ) return ((PsicoderVisitor<? extends T>)visitor).visitCasey(this);
			else return visitor.visitChildren(this);
		}
	}

	public final CaseyContext casey() throws RecognitionException {
		CaseyContext _localctx = new CaseyContext(_ctx, getState());
		enterRule(_localctx, 46, RULE_casey);
		try {
			setState(272);
			_errHandler.sync(this);
			switch (_input.LA(1)) {
			case TK_CASO:
				enterOuterAlt(_localctx, 1);
				{
				setState(262);
				match(TK_CASO);
				setState(263);
				vt();
				setState(264);
				match(TK_DOSP);
				setState(265);
				pyc();
				setState(266);
				casey();
				}
				break;
			case TK_DEFECTO:
				enterOuterAlt(_localctx, 2);
				{
				setState(268);
				match(TK_DEFECTO);
				setState(269);
				match(TK_DOSP);
				setState(270);
				pyc();
				}
				break;
			case TK_FINSELECCIONAR:
				enterOuterAlt(_localctx, 3);
				{
				}
				break;
			default:
				throw new NoViableAltException(this);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class EContext extends ParserRuleContext {
		public TerminalNode TK_ESTRUCTURA() { return getToken(PsicoderParser.TK_ESTRUCTURA, 0); }
		public TerminalNode ID() { return getToken(PsicoderParser.ID, 0); }
		public DContext d() {
			return getRuleContext(DContext.class,0);
		}
		public TerminalNode TK_FINESTRUCTURA() { return getToken(PsicoderParser.TK_FINESTRUCTURA, 0); }
		public EContext e() {
			return getRuleContext(EContext.class,0);
		}
		public FContext f() {
			return getRuleContext(FContext.class,0);
		}
		public EContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_e; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof PsicoderListener ) ((PsicoderListener)listener).enterE(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof PsicoderListener ) ((PsicoderListener)listener).exitE(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof PsicoderVisitor ) return ((PsicoderVisitor<? extends T>)visitor).visitE(this);
			else return visitor.visitChildren(this);
		}
	}

	public final EContext e() throws RecognitionException {
		EContext _localctx = new EContext(_ctx, getState());
		enterRule(_localctx, 48, RULE_e);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(274);
			match(TK_ESTRUCTURA);
			setState(275);
			match(ID);
			setState(276);
			d();
			setState(277);
			match(TK_FINESTRUCTURA);
			setState(278);
			e();
			setState(279);
			f();
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class VtContext extends ParserRuleContext {
		public TerminalNode TK_ENTERO() { return getToken(PsicoderParser.TK_ENTERO, 0); }
		public TerminalNode TK_REAL() { return getToken(PsicoderParser.TK_REAL, 0); }
		public TerminalNode TK_CADENA() { return getToken(PsicoderParser.TK_CADENA, 0); }
		public TerminalNode TK_CARACTER() { return getToken(PsicoderParser.TK_CARACTER, 0); }
		public TerminalNode VERDADERO() { return getToken(PsicoderParser.VERDADERO, 0); }
		public TerminalNode FALSO() { return getToken(PsicoderParser.FALSO, 0); }
		public VtContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_vt; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof PsicoderListener ) ((PsicoderListener)listener).enterVt(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof PsicoderListener ) ((PsicoderListener)listener).exitVt(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof PsicoderVisitor ) return ((PsicoderVisitor<? extends T>)visitor).visitVt(this);
			else return visitor.visitChildren(this);
		}
	}

	public final VtContext vt() throws RecognitionException {
		VtContext _localctx = new VtContext(_ctx, getState());
		enterRule(_localctx, 50, RULE_vt);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(281);
			_la = _input.LA(1);
			if ( !((((_la) & ~0x3f) == 0 && ((1L << _la) & ((1L << TK_ENTERO) | (1L << TK_REAL) | (1L << TK_CADENA) | (1L << TK_CARACTER) | (1L << VERDADERO) | (1L << FALSO))) != 0)) ) {
			_errHandler.recoverInline(this);
			}
			else {
				if ( _input.LA(1)==Token.EOF ) matchedEOF = true;
				_errHandler.reportMatch(this);
				consume();
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class OpaContext extends ParserRuleContext {
		public TerminalNode TK_MAS() { return getToken(PsicoderParser.TK_MAS, 0); }
		public TerminalNode TK_MENOS() { return getToken(PsicoderParser.TK_MENOS, 0); }
		public TerminalNode TK_MULT() { return getToken(PsicoderParser.TK_MULT, 0); }
		public TerminalNode TK_DIV() { return getToken(PsicoderParser.TK_DIV, 0); }
		public TerminalNode TK_MOD() { return getToken(PsicoderParser.TK_MOD, 0); }
		public OpaContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_opa; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof PsicoderListener ) ((PsicoderListener)listener).enterOpa(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof PsicoderListener ) ((PsicoderListener)listener).exitOpa(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof PsicoderVisitor ) return ((PsicoderVisitor<? extends T>)visitor).visitOpa(this);
			else return visitor.visitChildren(this);
		}
	}

	public final OpaContext opa() throws RecognitionException {
		OpaContext _localctx = new OpaContext(_ctx, getState());
		enterRule(_localctx, 52, RULE_opa);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(283);
			_la = _input.LA(1);
			if ( !((((_la) & ~0x3f) == 0 && ((1L << _la) & ((1L << TK_MAS) | (1L << TK_MENOS) | (1L << TK_MULT) | (1L << TK_DIV) | (1L << TK_MOD))) != 0)) ) {
			_errHandler.recoverInline(this);
			}
			else {
				if ( _input.LA(1)==Token.EOF ) matchedEOF = true;
				_errHandler.reportMatch(this);
				consume();
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class OplContext extends ParserRuleContext {
		public TerminalNode TK_MENOR() { return getToken(PsicoderParser.TK_MENOR, 0); }
		public TerminalNode TK_MAYOR() { return getToken(PsicoderParser.TK_MAYOR, 0); }
		public TerminalNode TK_MENOR_IGUAL() { return getToken(PsicoderParser.TK_MENOR_IGUAL, 0); }
		public TerminalNode TK_MAYOR_IGUAL() { return getToken(PsicoderParser.TK_MAYOR_IGUAL, 0); }
		public TerminalNode TK_IGUAL() { return getToken(PsicoderParser.TK_IGUAL, 0); }
		public TerminalNode TK_Y() { return getToken(PsicoderParser.TK_Y, 0); }
		public TerminalNode TK_O() { return getToken(PsicoderParser.TK_O, 0); }
		public TerminalNode TK_DIF() { return getToken(PsicoderParser.TK_DIF, 0); }
		public TerminalNode TK_NEG() { return getToken(PsicoderParser.TK_NEG, 0); }
		public OplContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_opl; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof PsicoderListener ) ((PsicoderListener)listener).enterOpl(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof PsicoderListener ) ((PsicoderListener)listener).exitOpl(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof PsicoderVisitor ) return ((PsicoderVisitor<? extends T>)visitor).visitOpl(this);
			else return visitor.visitChildren(this);
		}
	}

	public final OplContext opl() throws RecognitionException {
		OplContext _localctx = new OplContext(_ctx, getState());
		enterRule(_localctx, 54, RULE_opl);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(285);
			_la = _input.LA(1);
			if ( !((((_la) & ~0x3f) == 0 && ((1L << _la) & ((1L << TK_MENOR) | (1L << TK_MAYOR) | (1L << TK_MENOR_IGUAL) | (1L << TK_MAYOR_IGUAL) | (1L << TK_IGUAL) | (1L << TK_Y) | (1L << TK_O) | (1L << TK_DIF) | (1L << TK_NEG))) != 0)) ) {
			_errHandler.recoverInline(this);
			}
			else {
				if ( _input.LA(1)==Token.EOF ) matchedEOF = true;
				_errHandler.reportMatch(this);
				consume();
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static final String _serializedATN =
		"\3\u608b\ua72a\u8133\ub9ed\u417c\u3be7\u7786\u5964\3>\u0122\4\2\t\2\4"+
		"\3\t\3\4\4\t\4\4\5\t\5\4\6\t\6\4\7\t\7\4\b\t\b\4\t\t\t\4\n\t\n\4\13\t"+
		"\13\4\f\t\f\4\r\t\r\4\16\t\16\4\17\t\17\4\20\t\20\4\21\t\21\4\22\t\22"+
		"\4\23\t\23\4\24\t\24\4\25\t\25\4\26\t\26\4\27\t\27\4\30\t\30\4\31\t\31"+
		"\4\32\t\32\4\33\t\33\4\34\t\34\4\35\t\35\3\2\3\2\7\2=\n\2\f\2\16\2@\13"+
		"\2\3\2\3\2\3\2\3\2\3\2\5\2G\n\2\3\3\3\3\7\3K\n\3\f\3\16\3N\13\3\3\4\3"+
		"\4\3\4\3\4\3\4\3\4\3\4\3\4\3\4\3\4\3\4\3\4\3\4\3\4\3\4\5\4_\n\4\3\5\3"+
		"\5\5\5c\n\5\3\6\3\6\3\6\3\6\3\6\5\6j\n\6\3\7\3\7\3\7\3\7\3\7\5\7q\n\7"+
		"\3\b\3\b\3\b\3\b\3\b\3\b\5\by\n\b\3\t\3\t\3\t\3\t\3\t\3\t\3\t\3\t\5\t"+
		"\u0083\n\t\3\n\3\n\3\13\3\13\3\13\3\f\3\f\3\f\3\f\3\f\3\f\3\f\3\f\5\f"+
		"\u0092\n\f\3\r\3\r\3\r\3\r\3\r\3\r\3\r\3\r\3\r\3\r\3\r\3\r\3\r\3\r\5\r"+
		"\u00a2\n\r\3\16\3\16\5\16\u00a6\n\16\3\17\3\17\3\17\3\17\3\17\3\17\3\17"+
		"\3\17\3\17\5\17\u00b1\n\17\3\20\3\20\3\20\3\20\3\20\3\20\3\20\3\20\3\20"+
		"\3\20\3\20\3\20\3\20\3\20\3\20\5\20\u00c2\n\20\3\21\3\21\3\21\5\21\u00c7"+
		"\n\21\3\22\3\22\3\22\3\22\3\22\3\22\3\22\3\22\3\22\3\22\3\22\3\22\3\22"+
		"\3\22\3\23\3\23\3\23\3\23\3\23\3\23\3\23\3\23\3\23\3\24\3\24\3\24\5\24"+
		"\u00e3\n\24\3\25\3\25\3\25\3\25\3\25\3\25\3\25\3\25\3\25\3\25\3\25\3\25"+
		"\3\26\3\26\3\26\3\26\3\26\3\26\3\26\3\26\3\27\3\27\3\27\3\27\3\27\3\27"+
		"\3\27\3\27\3\30\3\30\3\30\3\30\3\30\3\30\3\30\3\30\3\31\3\31\3\31\3\31"+
		"\3\31\3\31\3\31\3\31\3\31\3\31\5\31\u0113\n\31\3\32\3\32\3\32\3\32\3\32"+
		"\3\32\3\32\3\33\3\33\3\34\3\34\3\35\3\35\3\35\2\2\36\2\4\6\b\n\f\16\20"+
		"\22\24\26\30\32\34\36 \"$&(*,.\60\62\64\668\2\6\3\2\5\t\3\2+\60\3\2\61"+
		"\65\3\2\66>\2\u0128\2F\3\2\2\2\4L\3\2\2\2\6^\3\2\2\2\bb\3\2\2\2\ni\3\2"+
		"\2\2\fp\3\2\2\2\16x\3\2\2\2\20\u0082\3\2\2\2\22\u0084\3\2\2\2\24\u0086"+
		"\3\2\2\2\26\u0091\3\2\2\2\30\u00a1\3\2\2\2\32\u00a5\3\2\2\2\34\u00b0\3"+
		"\2\2\2\36\u00c1\3\2\2\2 \u00c6\3\2\2\2\"\u00c8\3\2\2\2$\u00d6\3\2\2\2"+
		"&\u00e2\3\2\2\2(\u00e4\3\2\2\2*\u00f0\3\2\2\2,\u00f8\3\2\2\2.\u0100\3"+
		"\2\2\2\60\u0112\3\2\2\2\62\u0114\3\2\2\2\64\u011b\3\2\2\2\66\u011d\3\2"+
		"\2\28\u011f\3\2\2\2:=\5\"\22\2;=\5\62\32\2<:\3\2\2\2<;\3\2\2\2=@\3\2\2"+
		"\2><\3\2\2\2>?\3\2\2\2?A\3\2\2\2@>\3\2\2\2AB\7\3\2\2BC\5\4\3\2CD\7\4\2"+
		"\2DG\3\2\2\2EG\7\2\2\3F>\3\2\2\2FE\3\2\2\2G\3\3\2\2\2HK\5\16\b\2IK\5\f"+
		"\7\2JH\3\2\2\2JI\3\2\2\2KN\3\2\2\2LJ\3\2\2\2LM\3\2\2\2M\5\3\2\2\2NL\3"+
		"\2\2\2OP\5\24\13\2PQ\58\35\2QR\5\b\5\2RS\5\n\6\2S_\3\2\2\2TU\5\64\33\2"+
		"UV\58\35\2VW\5\b\5\2WX\5\n\6\2X_\3\2\2\2YZ\7$\2\2Z[\5\6\4\2[\\\7%\2\2"+
		"\\]\5\n\6\2]_\3\2\2\2^O\3\2\2\2^T\3\2\2\2^Y\3\2\2\2_\7\3\2\2\2`c\5\64"+
		"\33\2ac\5\24\13\2b`\3\2\2\2ba\3\2\2\2c\t\3\2\2\2de\58\35\2ef\5\6\4\2f"+
		"g\5\n\6\2gj\3\2\2\2hj\3\2\2\2id\3\2\2\2ih\3\2\2\2j\13\3\2\2\2kq\5$\23"+
		"\2lq\5(\25\2mq\5*\26\2nq\5,\27\2oq\5.\30\2pk\3\2\2\2pl\3\2\2\2pm\3\2\2"+
		"\2pn\3\2\2\2po\3\2\2\2q\r\3\2\2\2rs\5\20\t\2st\7&\2\2ty\3\2\2\2uv\5\36"+
		"\20\2vw\7&\2\2wy\3\2\2\2xr\3\2\2\2xu\3\2\2\2y\17\3\2\2\2z{\5\22\n\2{|"+
		"\5\24\13\2|}\5\30\r\2}\u0083\3\2\2\2~\177\5\24\13\2\177\u0080\5\30\r\2"+
		"\u0080\u0083\3\2\2\2\u0081\u0083\3\2\2\2\u0082z\3\2\2\2\u0082~\3\2\2\2"+
		"\u0082\u0081\3\2\2\2\u0083\21\3\2\2\2\u0084\u0085\t\2\2\2\u0085\23\3\2"+
		"\2\2\u0086\u0087\7\"\2\2\u0087\u0088\5\26\f\2\u0088\25\3\2\2\2\u0089\u008a"+
		"\7\'\2\2\u008a\u0092\7\"\2\2\u008b\u008c\7\"\2\2\u008c\u0092\5\26\f\2"+
		"\u008d\u008e\7(\2\2\u008e\u0092\5\26\f\2\u008f\u0092\7&\2\2\u0090\u0092"+
		"\3\2\2\2\u0091\u0089\3\2\2\2\u0091\u008b\3\2\2\2\u0091\u008d\3\2\2\2\u0091"+
		"\u008f\3\2\2\2\u0091\u0090\3\2\2\2\u0092\27\3\2\2\2\u0093\u0094\7)\2\2"+
		"\u0094\u0095\5\30\r\2\u0095\u0096\5\34\17\2\u0096\u00a2\3\2\2\2\u0097"+
		"\u0098\5\64\33\2\u0098\u0099\5\32\16\2\u0099\u009a\5\34\17\2\u009a\u00a2"+
		"\3\2\2\2\u009b\u009c\7$\2\2\u009c\u009d\5\30\r\2\u009d\u009e\7%\2\2\u009e"+
		"\u009f\5\34\17\2\u009f\u00a2\3\2\2\2\u00a0\u00a2\3\2\2\2\u00a1\u0093\3"+
		"\2\2\2\u00a1\u0097\3\2\2\2\u00a1\u009b\3\2\2\2\u00a1\u00a0\3\2\2\2\u00a2"+
		"\31\3\2\2\2\u00a3\u00a6\7(\2\2\u00a4\u00a6\3\2\2\2\u00a5\u00a3\3\2\2\2"+
		"\u00a5\u00a4\3\2\2\2\u00a6\33\3\2\2\2\u00a7\u00a8\5\66\34\2\u00a8\u00a9"+
		"\5\30\r\2\u00a9\u00aa\5\34\17\2\u00aa\u00b1\3\2\2\2\u00ab\u00ac\5\24\13"+
		"\2\u00ac\u00ad\5\30\r\2\u00ad\u00b1\3\2\2\2\u00ae\u00b1\7&\2\2\u00af\u00b1"+
		"\3\2\2\2\u00b0\u00a7\3\2\2\2\u00b0\u00ab\3\2\2\2\u00b0\u00ae\3\2\2\2\u00b0"+
		"\u00af\3\2\2\2\u00b1\35\3\2\2\2\u00b2\u00c2\7\n\2\2\u00b3\u00b4\7\13\2"+
		"\2\u00b4\u00b5\7$\2\2\u00b5\u00b6\7\"\2\2\u00b6\u00c2\7%\2\2\u00b7\u00b8"+
		"\7\f\2\2\u00b8\u00b9\7$\2\2\u00b9\u00ba\5 \21\2\u00ba\u00bb\7%\2\2\u00bb"+
		"\u00c2\3\2\2\2\u00bc\u00bd\7\"\2\2\u00bd\u00be\7$\2\2\u00be\u00bf\5\24"+
		"\13\2\u00bf\u00c0\7%\2\2\u00c0\u00c2\3\2\2\2\u00c1\u00b2\3\2\2\2\u00c1"+
		"\u00b3\3\2\2\2\u00c1\u00b7\3\2\2\2\u00c1\u00bc\3\2\2\2\u00c2\37\3\2\2"+
		"\2\u00c3\u00c7\5\24\13\2\u00c4\u00c7\5\30\r\2\u00c5\u00c7\5\34\17\2\u00c6"+
		"\u00c3\3\2\2\2\u00c6\u00c4\3\2\2\2\u00c6\u00c5\3\2\2\2\u00c7!\3\2\2\2"+
		"\u00c8\u00c9\7\r\2\2\u00c9\u00ca\5\22\n\2\u00ca\u00cb\7\"\2\2\u00cb\u00cc"+
		"\7$\2\2\u00cc\u00cd\5\24\13\2\u00cd\u00ce\7%\2\2\u00ce\u00cf\7\16\2\2"+
		"\u00cf\u00d0\5\16\b\2\u00d0\u00d1\7\17\2\2\u00d1\u00d2\5\24\13\2\u00d2"+
		"\u00d3\7\20\2\2\u00d3\u00d4\5\"\22\2\u00d4\u00d5\5\62\32\2\u00d5#\3\2"+
		"\2\2\u00d6\u00d7\7\21\2\2\u00d7\u00d8\7$\2\2\u00d8\u00d9\5\6\4\2\u00d9"+
		"\u00da\7%\2\2\u00da\u00db\7\22\2\2\u00db\u00dc\5\16\b\2\u00dc\u00dd\5"+
		"&\24\2\u00dd\u00de\7\23\2\2\u00de%\3\2\2\2\u00df\u00e0\7\24\2\2\u00e0"+
		"\u00e3\5\16\b\2\u00e1\u00e3\3\2\2\2\u00e2\u00df\3\2\2\2\u00e2\u00e1\3"+
		"\2\2\2\u00e3\'\3\2\2\2\u00e4\u00e5\7\25\2\2\u00e5\u00e6\7$\2\2\u00e6\u00e7"+
		"\5\24\13\2\u00e7\u00e8\7&\2\2\u00e8\u00e9\5\6\4\2\u00e9\u00ea\7&\2\2\u00ea"+
		"\u00eb\5\24\13\2\u00eb\u00ec\7%\2\2\u00ec\u00ed\7\16\2\2\u00ed\u00ee\5"+
		"\16\b\2\u00ee\u00ef\7\26\2\2\u00ef)\3\2\2\2\u00f0\u00f1\7\27\2\2\u00f1"+
		"\u00f2\7$\2\2\u00f2\u00f3\5\6\4\2\u00f3\u00f4\7%\2\2\u00f4\u00f5\7\16"+
		"\2\2\u00f5\u00f6\5\16\b\2\u00f6\u00f7\7\30\2\2\u00f7+\3\2\2\2\u00f8\u00f9"+
		"\7\16\2\2\u00f9\u00fa\5\16\b\2\u00fa\u00fb\7\27\2\2\u00fb\u00fc\7$\2\2"+
		"\u00fc\u00fd\5\6\4\2\u00fd\u00fe\7%\2\2\u00fe\u00ff\7&\2\2\u00ff-\3\2"+
		"\2\2\u0100\u0101\7\31\2\2\u0101\u0102\7$\2\2\u0102\u0103\7\"\2\2\u0103"+
		"\u0104\7%\2\2\u0104\u0105\7\32\2\2\u0105\u0106\5\60\31\2\u0106\u0107\7"+
		"\33\2\2\u0107/\3\2\2\2\u0108\u0109\7\34\2\2\u0109\u010a\5\64\33\2\u010a"+
		"\u010b\7*\2\2\u010b\u010c\5\16\b\2\u010c\u010d\5\60\31\2\u010d\u0113\3"+
		"\2\2\2\u010e\u010f\7\35\2\2\u010f\u0110\7*\2\2\u0110\u0113\5\16\b\2\u0111"+
		"\u0113\3\2\2\2\u0112\u0108\3\2\2\2\u0112\u010e\3\2\2\2\u0112\u0111\3\2"+
		"\2\2\u0113\61\3\2\2\2\u0114\u0115\7\36\2\2\u0115\u0116\7\"\2\2\u0116\u0117"+
		"\5\24\13\2\u0117\u0118\7\37\2\2\u0118\u0119\5\62\32\2\u0119\u011a\5\""+
		"\22\2\u011a\63\3\2\2\2\u011b\u011c\t\3\2\2\u011c\65\3\2\2\2\u011d\u011e"+
		"\t\4\2\2\u011e\67\3\2\2\2\u011f\u0120\t\5\2\2\u01209\3\2\2\2\25<>FJL^"+
		"bipx\u0082\u0091\u00a1\u00a5\u00b0\u00c1\u00c6\u00e2\u0112";
	public static final ATN _ATN =
		new ATNDeserializer().deserialize(_serializedATN.toCharArray());
	static {
		_decisionToDFA = new DFA[_ATN.getNumberOfDecisions()];
		for (int i = 0; i < _ATN.getNumberOfDecisions(); i++) {
			_decisionToDFA[i] = new DFA(_ATN.getDecisionState(i), i);
		}
	}
}