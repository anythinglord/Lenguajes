// Generated from /home/jesus/IdeaProjects/PsiCoder2/Psicoder.g4 by ANTLR 4.7
import org.antlr.v4.runtime.tree.ParseTreeVisitor;

/**
 * This interface defines a complete generic visitor for a parse tree produced
 * by {@link PsicoderParser}.
 *
 * @param <T> The return type of the visit operation. Use {@link Void} for
 * operations with no return type.
 */
public interface PsicoderVisitor<T> extends ParseTreeVisitor<T> {
	/**
	 * Visit a parse tree produced by {@link PsicoderParser#s}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitS(PsicoderParser.SContext ctx);
	/**
	 * Visit a parse tree produced by {@link PsicoderParser#code}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitCode(PsicoderParser.CodeContext ctx);
	/**
	 * Visit a parse tree produced by {@link PsicoderParser#cond}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitCond(PsicoderParser.CondContext ctx);
	/**
	 * Visit a parse tree produced by {@link PsicoderParser#cv}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitCv(PsicoderParser.CvContext ctx);
	/**
	 * Visit a parse tree produced by {@link PsicoderParser#cond1}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitCond1(PsicoderParser.Cond1Context ctx);
	/**
	 * Visit a parse tree produced by {@link PsicoderParser#sc}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitSc(PsicoderParser.ScContext ctx);
	/**
	 * Visit a parse tree produced by {@link PsicoderParser#pyc}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitPyc(PsicoderParser.PycContext ctx);
	/**
	 * Visit a parse tree produced by {@link PsicoderParser#dy}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitDy(PsicoderParser.DyContext ctx);
	/**
	 * Visit a parse tree produced by {@link PsicoderParser#t}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitT(PsicoderParser.TContext ctx);
	/**
	 * Visit a parse tree produced by {@link PsicoderParser#d}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitD(PsicoderParser.DContext ctx);
	/**
	 * Visit a parse tree produced by {@link PsicoderParser#d1}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitD1(PsicoderParser.D1Context ctx);
	/**
	 * Visit a parse tree produced by {@link PsicoderParser#a}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitA(PsicoderParser.AContext ctx);
	/**
	 * Visit a parse tree produced by {@link PsicoderParser#a1}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitA1(PsicoderParser.A1Context ctx);
	/**
	 * Visit a parse tree produced by {@link PsicoderParser#a2}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitA2(PsicoderParser.A2Context ctx);
	/**
	 * Visit a parse tree produced by {@link PsicoderParser#com}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitCom(PsicoderParser.ComContext ctx);
	/**
	 * Visit a parse tree produced by {@link PsicoderParser#m}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitM(PsicoderParser.MContext ctx);
	/**
	 * Visit a parse tree produced by {@link PsicoderParser#f}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitF(PsicoderParser.FContext ctx);
	/**
	 * Visit a parse tree produced by {@link PsicoderParser#ify}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitIfy(PsicoderParser.IfyContext ctx);
	/**
	 * Visit a parse tree produced by {@link PsicoderParser#elsey}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitElsey(PsicoderParser.ElseyContext ctx);
	/**
	 * Visit a parse tree produced by {@link PsicoderParser#fory}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitFory(PsicoderParser.ForyContext ctx);
	/**
	 * Visit a parse tree produced by {@link PsicoderParser#whiley}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitWhiley(PsicoderParser.WhileyContext ctx);
	/**
	 * Visit a parse tree produced by {@link PsicoderParser#do_whiley}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitDo_whiley(PsicoderParser.Do_whileyContext ctx);
	/**
	 * Visit a parse tree produced by {@link PsicoderParser#switchy}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitSwitchy(PsicoderParser.SwitchyContext ctx);
	/**
	 * Visit a parse tree produced by {@link PsicoderParser#casey}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitCasey(PsicoderParser.CaseyContext ctx);
	/**
	 * Visit a parse tree produced by {@link PsicoderParser#e}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitE(PsicoderParser.EContext ctx);
	/**
	 * Visit a parse tree produced by {@link PsicoderParser#vt}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitVt(PsicoderParser.VtContext ctx);
	/**
	 * Visit a parse tree produced by {@link PsicoderParser#opa}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitOpa(PsicoderParser.OpaContext ctx);
	/**
	 * Visit a parse tree produced by {@link PsicoderParser#opl}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitOpl(PsicoderParser.OplContext ctx);
}