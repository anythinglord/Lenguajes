// Generated from /home/jesus/IdeaProjects/PsiCoder2/Psicoder.g4 by ANTLR 4.7
import org.antlr.v4.runtime.tree.ParseTreeListener;

/**
 * This interface defines a complete listener for a parse tree produced by
 * {@link PsicoderParser}.
 */
public interface PsicoderListener extends ParseTreeListener {
	/**
	 * Enter a parse tree produced by {@link PsicoderParser#s}.
	 * @param ctx the parse tree
	 */
	void enterS(PsicoderParser.SContext ctx);
	/**
	 * Exit a parse tree produced by {@link PsicoderParser#s}.
	 * @param ctx the parse tree
	 */
	void exitS(PsicoderParser.SContext ctx);
	/**
	 * Enter a parse tree produced by {@link PsicoderParser#code}.
	 * @param ctx the parse tree
	 */
	void enterCode(PsicoderParser.CodeContext ctx);
	/**
	 * Exit a parse tree produced by {@link PsicoderParser#code}.
	 * @param ctx the parse tree
	 */
	void exitCode(PsicoderParser.CodeContext ctx);
	/**
	 * Enter a parse tree produced by {@link PsicoderParser#cond}.
	 * @param ctx the parse tree
	 */
	void enterCond(PsicoderParser.CondContext ctx);
	/**
	 * Exit a parse tree produced by {@link PsicoderParser#cond}.
	 * @param ctx the parse tree
	 */
	void exitCond(PsicoderParser.CondContext ctx);
	/**
	 * Enter a parse tree produced by {@link PsicoderParser#cv}.
	 * @param ctx the parse tree
	 */
	void enterCv(PsicoderParser.CvContext ctx);
	/**
	 * Exit a parse tree produced by {@link PsicoderParser#cv}.
	 * @param ctx the parse tree
	 */
	void exitCv(PsicoderParser.CvContext ctx);
	/**
	 * Enter a parse tree produced by {@link PsicoderParser#cond1}.
	 * @param ctx the parse tree
	 */
	void enterCond1(PsicoderParser.Cond1Context ctx);
	/**
	 * Exit a parse tree produced by {@link PsicoderParser#cond1}.
	 * @param ctx the parse tree
	 */
	void exitCond1(PsicoderParser.Cond1Context ctx);
	/**
	 * Enter a parse tree produced by {@link PsicoderParser#sc}.
	 * @param ctx the parse tree
	 */
	void enterSc(PsicoderParser.ScContext ctx);
	/**
	 * Exit a parse tree produced by {@link PsicoderParser#sc}.
	 * @param ctx the parse tree
	 */
	void exitSc(PsicoderParser.ScContext ctx);
	/**
	 * Enter a parse tree produced by {@link PsicoderParser#pyc}.
	 * @param ctx the parse tree
	 */
	void enterPyc(PsicoderParser.PycContext ctx);
	/**
	 * Exit a parse tree produced by {@link PsicoderParser#pyc}.
	 * @param ctx the parse tree
	 */
	void exitPyc(PsicoderParser.PycContext ctx);
	/**
	 * Enter a parse tree produced by {@link PsicoderParser#dy}.
	 * @param ctx the parse tree
	 */
	void enterDy(PsicoderParser.DyContext ctx);
	/**
	 * Exit a parse tree produced by {@link PsicoderParser#dy}.
	 * @param ctx the parse tree
	 */
	void exitDy(PsicoderParser.DyContext ctx);
	/**
	 * Enter a parse tree produced by {@link PsicoderParser#t}.
	 * @param ctx the parse tree
	 */
	void enterT(PsicoderParser.TContext ctx);
	/**
	 * Exit a parse tree produced by {@link PsicoderParser#t}.
	 * @param ctx the parse tree
	 */
	void exitT(PsicoderParser.TContext ctx);
	/**
	 * Enter a parse tree produced by {@link PsicoderParser#d}.
	 * @param ctx the parse tree
	 */
	void enterD(PsicoderParser.DContext ctx);
	/**
	 * Exit a parse tree produced by {@link PsicoderParser#d}.
	 * @param ctx the parse tree
	 */
	void exitD(PsicoderParser.DContext ctx);
	/**
	 * Enter a parse tree produced by {@link PsicoderParser#d1}.
	 * @param ctx the parse tree
	 */
	void enterD1(PsicoderParser.D1Context ctx);
	/**
	 * Exit a parse tree produced by {@link PsicoderParser#d1}.
	 * @param ctx the parse tree
	 */
	void exitD1(PsicoderParser.D1Context ctx);
	/**
	 * Enter a parse tree produced by {@link PsicoderParser#a}.
	 * @param ctx the parse tree
	 */
	void enterA(PsicoderParser.AContext ctx);
	/**
	 * Exit a parse tree produced by {@link PsicoderParser#a}.
	 * @param ctx the parse tree
	 */
	void exitA(PsicoderParser.AContext ctx);
	/**
	 * Enter a parse tree produced by {@link PsicoderParser#a1}.
	 * @param ctx the parse tree
	 */
	void enterA1(PsicoderParser.A1Context ctx);
	/**
	 * Exit a parse tree produced by {@link PsicoderParser#a1}.
	 * @param ctx the parse tree
	 */
	void exitA1(PsicoderParser.A1Context ctx);
	/**
	 * Enter a parse tree produced by {@link PsicoderParser#a2}.
	 * @param ctx the parse tree
	 */
	void enterA2(PsicoderParser.A2Context ctx);
	/**
	 * Exit a parse tree produced by {@link PsicoderParser#a2}.
	 * @param ctx the parse tree
	 */
	void exitA2(PsicoderParser.A2Context ctx);
	/**
	 * Enter a parse tree produced by {@link PsicoderParser#com}.
	 * @param ctx the parse tree
	 */
	void enterCom(PsicoderParser.ComContext ctx);
	/**
	 * Exit a parse tree produced by {@link PsicoderParser#com}.
	 * @param ctx the parse tree
	 */
	void exitCom(PsicoderParser.ComContext ctx);
	/**
	 * Enter a parse tree produced by {@link PsicoderParser#m}.
	 * @param ctx the parse tree
	 */
	void enterM(PsicoderParser.MContext ctx);
	/**
	 * Exit a parse tree produced by {@link PsicoderParser#m}.
	 * @param ctx the parse tree
	 */
	void exitM(PsicoderParser.MContext ctx);
	/**
	 * Enter a parse tree produced by {@link PsicoderParser#f}.
	 * @param ctx the parse tree
	 */
	void enterF(PsicoderParser.FContext ctx);
	/**
	 * Exit a parse tree produced by {@link PsicoderParser#f}.
	 * @param ctx the parse tree
	 */
	void exitF(PsicoderParser.FContext ctx);
	/**
	 * Enter a parse tree produced by {@link PsicoderParser#ify}.
	 * @param ctx the parse tree
	 */
	void enterIfy(PsicoderParser.IfyContext ctx);
	/**
	 * Exit a parse tree produced by {@link PsicoderParser#ify}.
	 * @param ctx the parse tree
	 */
	void exitIfy(PsicoderParser.IfyContext ctx);
	/**
	 * Enter a parse tree produced by {@link PsicoderParser#elsey}.
	 * @param ctx the parse tree
	 */
	void enterElsey(PsicoderParser.ElseyContext ctx);
	/**
	 * Exit a parse tree produced by {@link PsicoderParser#elsey}.
	 * @param ctx the parse tree
	 */
	void exitElsey(PsicoderParser.ElseyContext ctx);
	/**
	 * Enter a parse tree produced by {@link PsicoderParser#fory}.
	 * @param ctx the parse tree
	 */
	void enterFory(PsicoderParser.ForyContext ctx);
	/**
	 * Exit a parse tree produced by {@link PsicoderParser#fory}.
	 * @param ctx the parse tree
	 */
	void exitFory(PsicoderParser.ForyContext ctx);
	/**
	 * Enter a parse tree produced by {@link PsicoderParser#whiley}.
	 * @param ctx the parse tree
	 */
	void enterWhiley(PsicoderParser.WhileyContext ctx);
	/**
	 * Exit a parse tree produced by {@link PsicoderParser#whiley}.
	 * @param ctx the parse tree
	 */
	void exitWhiley(PsicoderParser.WhileyContext ctx);
	/**
	 * Enter a parse tree produced by {@link PsicoderParser#do_whiley}.
	 * @param ctx the parse tree
	 */
	void enterDo_whiley(PsicoderParser.Do_whileyContext ctx);
	/**
	 * Exit a parse tree produced by {@link PsicoderParser#do_whiley}.
	 * @param ctx the parse tree
	 */
	void exitDo_whiley(PsicoderParser.Do_whileyContext ctx);
	/**
	 * Enter a parse tree produced by {@link PsicoderParser#switchy}.
	 * @param ctx the parse tree
	 */
	void enterSwitchy(PsicoderParser.SwitchyContext ctx);
	/**
	 * Exit a parse tree produced by {@link PsicoderParser#switchy}.
	 * @param ctx the parse tree
	 */
	void exitSwitchy(PsicoderParser.SwitchyContext ctx);
	/**
	 * Enter a parse tree produced by {@link PsicoderParser#casey}.
	 * @param ctx the parse tree
	 */
	void enterCasey(PsicoderParser.CaseyContext ctx);
	/**
	 * Exit a parse tree produced by {@link PsicoderParser#casey}.
	 * @param ctx the parse tree
	 */
	void exitCasey(PsicoderParser.CaseyContext ctx);
	/**
	 * Enter a parse tree produced by {@link PsicoderParser#e}.
	 * @param ctx the parse tree
	 */
	void enterE(PsicoderParser.EContext ctx);
	/**
	 * Exit a parse tree produced by {@link PsicoderParser#e}.
	 * @param ctx the parse tree
	 */
	void exitE(PsicoderParser.EContext ctx);
	/**
	 * Enter a parse tree produced by {@link PsicoderParser#vt}.
	 * @param ctx the parse tree
	 */
	void enterVt(PsicoderParser.VtContext ctx);
	/**
	 * Exit a parse tree produced by {@link PsicoderParser#vt}.
	 * @param ctx the parse tree
	 */
	void exitVt(PsicoderParser.VtContext ctx);
	/**
	 * Enter a parse tree produced by {@link PsicoderParser#opa}.
	 * @param ctx the parse tree
	 */
	void enterOpa(PsicoderParser.OpaContext ctx);
	/**
	 * Exit a parse tree produced by {@link PsicoderParser#opa}.
	 * @param ctx the parse tree
	 */
	void exitOpa(PsicoderParser.OpaContext ctx);
	/**
	 * Enter a parse tree produced by {@link PsicoderParser#opl}.
	 * @param ctx the parse tree
	 */
	void enterOpl(PsicoderParser.OplContext ctx);
	/**
	 * Exit a parse tree produced by {@link PsicoderParser#opl}.
	 * @param ctx the parse tree
	 */
	void exitOpl(PsicoderParser.OplContext ctx);
}