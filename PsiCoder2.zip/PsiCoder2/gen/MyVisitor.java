

import java.sql.SQLOutput;
import java.util.HashMap;
public class MyVisitor<T> extends PsicoderBaseVisitor {
    HashMap<String,Object> table = new HashMap<>();

    /*@Override
    public T visitS(PsicoderParser.SContext ctx){
        return null;
    }*/

    @Override
    public T visitCode(PsicoderParser.CodeContext ctx){
        System.out.println("in code");
        return (T)visitChildren(ctx);
        //return null;
    }

    @Override
    public T visitCond(PsicoderParser.CondContext ctx){
        if(ctx.TK_PAR_IZQ() != null){
            return visitCond(ctx.cond());
        }else{
            return (T)visitChildren(ctx);
        }
        //return null;
    }

    @Override
    public T visitCv(PsicoderParser.CvContext ctx){

        return (T)visitChildren(ctx);
        //return null;
    }

    @Override
    public T visitCond1(PsicoderParser.Cond1Context ctx){

        return (T)visitChildren(ctx);
        //return null;
    }

    @Override
    public T visitSc(PsicoderParser.ScContext ctx){

        return (T)visitChildren(ctx);
        //return null;
    }

    @Override
    public T visitPyc(PsicoderParser.PycContext ctx){
        System.out.println("in pyc");
        return (T)visitChildren(ctx);
        //return null;
    }

    @Override
    public T visitDy(PsicoderParser.DyContext ctx){
        System.out.println("in DY");
        String value = ctx.a().getText();
        table.put(ctx.d().getText(),value.substring(1));
        return (T)visitChildren(ctx);
        //return null;
    }

    // FAlta completarlo
    @Override
    public T visitT(PsicoderParser.TContext ctx){
        System.out.println("in T");
        //System.out.println(ctx.TK_INT().getText());
        if(ctx.TK_CHAR()!=null){
            return (T)ctx.TK_CHAR().getText();
        }
        else if(ctx.TK_BOOL()!=null){
            return (T)ctx.TK_BOOL().getText();
        }
        else if(ctx.TK_CAD()!=null){
            return (T)ctx.TK_CAD().getText();
        }
        else if(ctx.TK_INT()!=null){
            System.out.println("sirve el int");
            return (T)ctx.TK_INT().getText();
        }
        else if(ctx.TK_DOUBLE()!=null){
            return (T)ctx.TK_DOUBLE().getText();
        }
        return null;
    }

    @Override
    public T visitD(PsicoderParser.DContext ctx){
        System.out.println("in D");
        if(ctx.ID()!=null){
            if (visitD1(ctx.d1())!=null){
                return visitD1(ctx.d1());
            }else{
                return (T)ctx.ID().getText();
            }
            //return visitD1(ctx.d1());
        }
        return null;
    }

    @Override
    public T visitD1(PsicoderParser.D1Context ctx){
        System.out.println("in D1");
        if(ctx.TK_PUNTO()!=null){
            String name = ctx.ID().getText();
            Object value;
            if( (value = table.get(name))==null){
                int line = ctx.ID().getSymbol().getLine();
                int col = ctx.ID().getSymbol().getCharPositionInLine()+1;
                //Prodría ser en .out tambien.
                System.err.printf("<%d:%d> Error semantico, la variable con nombre \"" + name + "\" no fue declarada.\n",line,col);
                System.exit(-1);
                return null;
            }else{
                return (T)value;
            }
        }
        else if(ctx.ID()!=null){
            return visitD1(ctx.d1());
        }
        else if(ctx.TK_COMA()!=null){
            return visitD1(ctx.d1());
        }
        else if(ctx.TK_PYC()!=null){
            return (T)ctx.TK_PYC().getText();
        }
        return null;
    }
    @Override
    public T visitA(PsicoderParser.AContext ctx){
        System.out.println("in A");
        if(ctx.TK_ASIG()!=null){
            System.out.println("igualito-a");
            return visitA(ctx.a());
        }else if(ctx.TK_PAR_IZQ()!=null){
            return visitA(ctx.a());
        }else {
            String response = (String)visitChildren(ctx);
            if (response == null){

                if (ctx.a2().getText().equals("")){
                    return (T)ctx.vt().getText();
                }else{

                    String normal = ctx.a2().getText();
                    String op = normal.substring(0,1);
                    int result = 0;
                    int num = Integer.parseInt(normal.substring(1));
                    switch (op){
                        case "+":
                            result = Integer.parseInt(ctx.vt().getText()) + num;
                            break;
                    }

                    System.out.println("ese op: "+result);
                    return (T)String.valueOf(result);
                }

            }else{
                return (T)visitChildren(ctx);
            }
            //return (T)visitChildren(ctx);
        }
        //return (T)super.visitA(ctx);
        //return null;
    }

    @Override
    public T visitA1(PsicoderParser.A1Context ctx){
        System.out.println("in A1");
        if(ctx.TK_COMA()!=null){
            return (T)ctx.TK_COMA().getText();
        }else{
            System.out.println("A1 null");
            return null;
        }
        //return (T)super.visitA1(ctx);
        //return null;
    }

    @Override
    public T visitA2(PsicoderParser.A2Context ctx){
        System.out.println("in A2");
        System.out.println("ctx-a2:"+ctx.getText());
        if(ctx.TK_PYC()!=null){
            return (T)ctx.TK_PYC().getText();
        }else{
            return (T)visitChildren(ctx);
        }

        //return (T)super.visitA2(ctx);
        //return null;
    }

    @Override
    public T visitCom(PsicoderParser.ComContext ctx){
        System.out.println("in com");
        if(ctx.ID()!=null){
            return visitD(ctx.d());
        }
        else if(ctx.TK_ROMPER()!=null){
            return (T)ctx.TK_ROMPER().getText();
        }
        else if(ctx.TK_LEER()!=null){
            return (T)ctx.TK_ROMPER().getText();
        }
        else if(ctx.TK_IMPRIMIR()!=null){
            System.out.println("com-imprim");
            return (T)visitM(ctx.m());
        }
        //return (T)super.visitA2(ctx);
        return null;
    }

    @Override
    public T visitM(PsicoderParser.MContext ctx){
        System.out.println("in M");
        if(visitChildren(ctx) !=null){
            System.out.println("no null");
            String var = (String)visitChildren(ctx);
            System.out.println("var: "+var);
            if (var.charAt(0)>= 48 && var.charAt(0)<= 57){
                System.out.println(var);
            }else{
                System.out.println(table.get(var));
            }
            //System.out.println("vtx:"+visitVt(ctx.a().vt()));
            //System.out.println(table.get(var));

        }
        //return (T)visitChildren(ctx);
        return null;
    }

    @Override
    public T visitF(PsicoderParser.FContext ctx){
        if(ctx.TK_FUNCION()!=null){
            return visitT(ctx.t());
        }
        return (T)super.visitF(ctx);
    }

    @Override
    public T visitIfy(PsicoderParser.IfyContext ctx){
        if(ctx.TK_SI()!=null){
            return visitCond(ctx.cond());
        }
        return (T)super.visitIfy(ctx);
    }

    @Override
    public T visitElsey(PsicoderParser.ElseyContext ctx){
        if(ctx.TK_SINO()!=null){
            return visitPyc(ctx.pyc());
        }
        return (T)super.visitElsey(ctx);
    }

    @Override
    public T visitFory(PsicoderParser.ForyContext ctx){
        if(ctx.TK_PARA()!=null){
            return visitD(ctx.d(0));
        }
        return (T)super.visitFory(ctx);
    }

    @Override
    public T visitWhiley(PsicoderParser.WhileyContext ctx){
        if(ctx.TK_MIENTRAS()!=null){
            return visitCond(ctx.cond());
        }
        return (T)super.visitWhiley(ctx);
    }

    @Override
    public T visitDo_whiley(PsicoderParser.Do_whileyContext ctx){
        if(ctx.TK_HACER()!=null){
            return visitPyc(ctx.pyc());
        }
        return (T)super.visitDo_whiley(ctx);
    }

    @Override
    public T visitSwitchy(PsicoderParser.SwitchyContext ctx){
        if(ctx.TK_SELECCIONAR()!=null){
            return (T) visitCasey(ctx.casey());
        }
        return (T)super.visitSwitchy(ctx);
    }

    @Override
    public T visitE(PsicoderParser.EContext ctx){
        if(ctx.TK_ESTRUCTURA()!=null){
            return (T) visitD(ctx.d());
        }
        return (T)super.visitE(ctx);
    }

    @Override
    public T visitVt(PsicoderParser.VtContext ctx){
        System.out.println("in Vt");
        if(ctx.TK_ENTERO()!=null){
            System.out.println("vt-entero");
            System.out.println("vt-txt:"+ctx.getText());
            return (T)ctx.TK_ENTERO().getText();
        }
        else if(ctx.TK_REAL()!=null){
            return (T)ctx.TK_REAL().getText();
        }
        else if(ctx.TK_CADENA()!=null){
            return (T)ctx.TK_CADENA().getText();
        }
        else if(ctx.TK_CARACTER()!=null){
            return (T)ctx.TK_CARACTER().getText();
        }
        else if(ctx.VERDADERO()!=null){
            return (T)ctx.VERDADERO().getText();
        }
        else if(ctx.FALSO()!=null){
            return (T)ctx.FALSO().getText();
        }
        return (T)super.visitVt(ctx);
    }

    @Override
    public T visitOpa(PsicoderParser.OpaContext ctx){
        System.out.println("in OPA");
        if(ctx.TK_MAS()!=null){
            System.out.println("opa +");
            return (T)ctx.TK_MAS().getText();
        }
        else if(ctx.TK_MENOS()!=null){
            return (T)ctx.TK_MENOS().getText();
        }
        else if(ctx.TK_MULT()!=null){
            return (T)ctx.TK_MULT().getText();
        }
        else if(ctx.TK_DIV()!=null){
            return (T)ctx.TK_DIV().getText();
        }
        else if(ctx.TK_MOD()!=null){
            return (T)ctx.TK_MOD().getText();
        }
        return (T)super.visitOpa(ctx);
    }

    @Override
    public T visitOpl(PsicoderParser.OplContext ctx){

        if(ctx.TK_MENOR()!=null){
            return (T)ctx.TK_MENOR().getText();
        }
        else if(ctx.TK_MAYOR()!=null){
            return (T)ctx.TK_MAYOR().getText();
        }
        else if(ctx.TK_MENOR_IGUAL()!=null){
            return (T)ctx.TK_MENOR_IGUAL().getText();
        }
        else if(ctx.TK_MAYOR_IGUAL()!=null){
            return (T)ctx.TK_MAYOR_IGUAL().getText();
        }
        else if(ctx.TK_IGUAL()!=null){
            return (T)ctx.TK_IGUAL().getText();
        }
        else if(ctx.TK_Y()!=null){
            return (T)ctx.TK_Y().getText();
        }
        else if(ctx.TK_O()!=null){
            return (T)ctx.TK_O().getText();
        }
        else if(ctx.TK_DIF()!=null){
            return (T)ctx.TK_DIF().getText();
        }
        else if(ctx.TK_NEG()!=null){
            return (T)ctx.TK_NEG().getText();
        }
        return (T)super.visitOpl(ctx);
    }
}
